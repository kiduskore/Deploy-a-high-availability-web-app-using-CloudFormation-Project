Udacity_Deploy-a-High-Availability-Web-App-using-CloudFormation

This is a the second project in the AWS Cloud DevOps Engineer Udacity Nanodegree.